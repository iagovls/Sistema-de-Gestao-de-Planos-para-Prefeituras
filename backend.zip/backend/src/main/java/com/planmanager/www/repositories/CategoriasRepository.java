package com.planmanager.www.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.planmanager.www.model.categorias.Categoria;

public interface CategoriasRepository extends JpaRepository<Categoria, Integer> {

}
