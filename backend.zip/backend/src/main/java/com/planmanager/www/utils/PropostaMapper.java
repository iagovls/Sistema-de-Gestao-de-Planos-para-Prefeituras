package com.planmanager.www.utils;

import com.planmanager.www.model.categorias.Categoria;
import com.planmanager.www.model.eixos.Eixo;
import com.planmanager.www.model.orgaos.OrgaoGestor;
import com.planmanager.www.model.planos.Plano;
import com.planmanager.www.model.prefeituras.Prefeitura;
import com.planmanager.www.model.propostas.Proposta;
import com.planmanager.www.model.propostas.dto.PropostaRequestDTO;

public class PropostaMapper {

    public static Proposta toEntity
            (
                    PropostaRequestDTO dto,
                    Prefeitura prefeitura,
                    Plano plano,
                    Eixo eixo,
                    Categoria categoria,
                    OrgaoGestor orgaoGestor
            ) {
        Proposta proposta = new Proposta();
        proposta.setTitulo(dto.titulo());
        proposta.setMeta(dto.meta());
        proposta.setStatus(dto.status());
        proposta.setAtiva(dto.ativa());
        proposta.setPlano(plano);
        proposta.setEixo(eixo);
        proposta.setCategoria(categoria);
        proposta.setOrgaoGestor(orgaoGestor);
        proposta.setMotivo(dto.motivo());
        proposta.setMetaPermanente(Boolean.TRUE.equals(dto.metaPermanente()));
        proposta.setPrefeitura(prefeitura);
        return proposta;
    }
}
